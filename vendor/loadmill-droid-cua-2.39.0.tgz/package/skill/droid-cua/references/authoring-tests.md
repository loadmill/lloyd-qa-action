# Authoring tests

## Inspect first

Find nearby `.dcua` tests and project files before writing. Match their directory layout, naming, vocabulary, starting state, and config conventions. Do not open `.env` or `.secrets`.

## Write `.dcua` instructions

- Put one clear user goal or assertion on each non-empty line. One instruction does not need to equal one UI action.
- Write concise, human-readable business or journey instructions that describe what the user wants to accomplish. Prefer `Select the desired date` or `Log out` over separate instructions for opening a picker or menu, clicking controls, handling an expected confirmation, and submitting.
- Do not prescribe coordinates, selectors, implementation details, model strategy, or every tap and keystroke. These micro-steps couple the test to incidental UI structure, add model rounds, and make harmless UI changes more likely to break it.
- Break a business-level instruction into smaller actions only when run evidence shows that the agent cannot complete it reliably or the intermediate state is itself behavior the test must verify.
- State the starting condition when it is not guaranteed by the environment.
- Use explicit assertions for important outcomes. Prefer stable visible facts such as a screen title, confirmation message, changed value, or navigation result.
- Use exact visible labels when naming controls or outcomes.
- Keep each new test focused on one behavior. Separate unrelated flows only when each resulting test is fully independent and does not rely on execution order or state created by another test.
- When updating or optimizing an existing test, preserve its complete flow in one `.dcua` file. Do not split it into sequential or dependent tests unless the user explicitly requests that structure and the project has a verified orchestration mechanism that guarantees ordering and shared state.
- Use `//` comments sparingly for human context; comments are not executed.
- Never include secret values in the test.

Example:

```text
Sign in using the USER_EMAIL and USER_PASSWORD secrets.
Assert that the Home screen is visible and shows the signed-in account.
Select December 15 as the requested date.
Assert that December 15 is shown as the requested date.
Log out.
Assert that the sign-in screen is visible.
```

Keep meaningful outcomes explicit even when actions are high-level. For example, follow `Log out` with an assertion that the sign-in screen is visible when logout behavior is under test.

Use the secret key names that exist in `.secrets`; do not inspect their values. If key discovery is necessary, filter the file so only keys reach output, for example `sed -n 's/^\([^#][^=]*\)=.*/\1/p' .secrets`. If a required key is absent, ask the user to add it without sharing its value.

## Invoke a saved Loadmill flow

When a test should run an existing Loadmill flow, invoke it either with the explicit `loadmill: <request>` form or with a natural-language instruction that clearly mentions Loadmill, such as `Run the Loadmill <flow name> flow with username=name.` Describe the flow with its exact or distinctive name. If several flows could match, ask the user for identifying terms before writing the test.

The request is interpreted as natural language. When passing runtime parameter overrides, prefer `name=value`, because that is the explicitly supported extraction format; include it naturally in the request rather than treating the whole instruction as rigid syntax.

```text
loadmill: create premium customer with country=US
Sign in as the customer created by the Loadmill flow.
Assert that the Premium dashboard is visible.
```

Droid searches for the best matching Loadmill flow, starts it, and waits for it to finish before continuing. On success, relevant returned parameters can be added to the agent context for later instructions. Refer to those values semantically, as in the example; do not invent placeholder syntax such as `{email}` or include returned values in the `.dcua` file.

## Put knowledge in the right place

- Put durable product behavior, terminology, stable navigation knowledge, and recurring product-specific confirmations in `context.md`, not repeated in every test. Use context to make business intent unambiguous, not to hide a scenario-specific micro-script.
- Put non-secret reusable people, accounts, products, and scenario combinations in `test-data.md`.
- Put credentials and sensitive values in `.secrets`.
- Put reproducible headless settings in `ci/droid-cua.json`.
- Keep environment and provider credentials in `.env` or the shell/CI secret store.

Use one shared context file and one shared Droid CUA config file for the project:

- Find the canonical files from nearby tests, existing commands, and config references before creating anything. If they exist, update them in place; do not create files such as `<test-name>-context.md` or `<test-name>-config.json`.
- Add only durable, project-wide knowledge to the shared context. Keep scenario-specific steps, values, and expected outcomes in the `.dcua` test or test data.
- Treat the shared config as affecting every project test. Review its existing consumers and likely impact before changing it. Use a CLI override for a temporary experiment, then persist the setting in the canonical config only when it is intended to become the project-wide behavior.
- If the project has no context or config, create at most one canonical file of each kind using its established directory and naming conventions.

Use `--scenario "<goal>" --test-data <path>` only when the user wants generated permutations or cases. A normal `.dcua` run does not automatically consume `test-data.md`.

After editing, show the user the test instructions and explain any new context, data keys, or secret keys required. Never show secret values.

Do not call a new or materially changed test complete after static validation. Continue with the confirmed baseline, evidence analysis, and stability workflow in [iterative-improvement.md](iterative-improvement.md).
