# Onboarding and troubleshooting

Follow the Desktop Device Setup Wizard sequence: choose a platform, run checks, discover/connect a target, verify runtime access during the requested run, then continue the original task. Run authentication as the separate first preflight described in `project-and-auth.md`.

Do not create or modify user test files merely to perform setup. Get approval before installing software, changing system configuration, running `sudo`, or accepting a license. After remediation, rerun only the failed check.

## Droid CUA CLI compatibility

If the CLI rejects a model, option, command, or capability that this skill explicitly documents, treat an outdated global `@loadmill/droid-cua` package as a likely setup issue. Do not suggest an update for an ordinary test, target, provider, or application failure.

Check the installed and latest published versions:

```sh
npm list -g @loadmill/droid-cua --depth=0
npm view @loadmill/droid-cua version
```

If the global package is missing or behind the published version, explain the mismatch and get approval before updating it:

```sh
npm install -g @loadmill/droid-cua@latest
```

After the update, rerun only the rejected command or failed readiness check, then resume the original task.

## Android

Resolve `adb` and `emulator` from `ANDROID_HOME`, `ANDROID_SDK_ROOT`, the macOS default `~/Library/Android/sdk`, the Windows default `%LOCALAPPDATA%\Android\Sdk`, then `PATH`. Respect explicit `DROID_CUA_ANDROID_ADB_PATH` and `DROID_CUA_ANDROID_EMULATOR_PATH` overrides.

Run these checks:

```sh
adb version
emulator -list-avds
adb devices
```

- `adb` is blocking.
- The emulator CLI and existence of an AVD are individually non-blocking.
- Target availability is blocking and passes when `adb devices` contains a `device` entry or `emulator -list-avds` contains a launchable AVD.
- For `unauthorized`, ask the user to accept the computer authorization prompt on the device.
- For `offline`, reconnect the device or restart ADB, then retry.
- If nothing is available, guide the user to connect a device or create an AVD in Android Studio Device Manager.

Use `--avd adb:<serial>` for an attached target and `--avd avd:<name>` to launch an AVD.

## iOS

Local iOS execution requires macOS. Run checks in this order:

```sh
xcrun --version
xcode-select -p
xcodebuild -license check
xcodebuild -checkFirstLaunchStatus
node --version
npm --version
appium --version
appium driver list --installed
xcrun simctl list devices --json
```

Require `xcode-select -p` to point to an `/Xcode*.app/Contents/Developer` path, an installed XCUITest driver, and at least one available iPhone simulator. A booted simulator is helpful but not blocking.

Offer only the relevant remediation, with approval:

```sh
sudo xcode-select -s /Applications/Xcode.app/Contents/Developer
sudo xcodebuild -license accept
sudo xcodebuild -runFirstLaunch
npm install -g appium
appium driver install xcuitest
```

Use `--platform ios --avd "<simulator name>"` for the run.

## Web

Droid CUA automatically discovers Chrome or Edge on macOS and Windows. Check the standard application locations, then run the requested test with `--target web --browser <chrome|edge> --session-mode fresh`. A successful Playwright launch is the runtime verification; do not create a persistent setup-only test.

On Linux, automatic installed-browser discovery is not currently supported. Do not claim that a PATH-installed browser will be found.

## Cloud targets

For LambdaTest, require `LAMBDATEST_USERNAME`, `LAMBDATEST_ACCESS_KEY`, a device name, OS version, and `.apk` or `.ipa`. The CLI uploads the app for each run.

For AWS Device Farm, require `AWS_DEVICE_FARM_ACCESS_KEY_ID`, `AWS_DEVICE_FARM_SECRET_ACCESS_KEY`, and `AWS_DEVICE_FARM_PROJECT_ARN`. Discover targets with:

```sh
droid-cua --device-source aws-device-farm --list-devices
```

Do not document BrowserStack CLI runs; BrowserStack is not consistently exposed by the current CLI.
