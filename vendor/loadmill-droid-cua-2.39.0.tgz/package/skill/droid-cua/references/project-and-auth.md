# Project files and authentication

## Project files

- `.dcua`: executable test instructions. Each non-empty line is one instruction; `//` begins a comment.
- `context.md`: durable knowledge about product terminology, screens, navigation, and behavior. Pass it with `--context`, or reference it from `ci/droid-cua.json`.
- `test-data.md`: non-secret entities and scenario inputs. It is used with `--scenario` and `--test-data`; it is not automatically loaded by every normal test run.
- `.secrets`: dotenv-style values that Droid CUA may type into the tested application. The model receives the keys, not the resolved values. Headless execution loads this file from the current working directory; `--secrets` overrides it.
- `.env`: infrastructure credentials and runtime environment variables loaded from the current working directory, including `LOADMILL_API_TOKEN`.
- `ci/droid-cua.json`: optional checked-in headless config. Paths inside it are relative to the config file.
- `logs/`: structured JSONL and screenshot artifacts created by `--debug`.
- HTML reports: self-contained evidence produced by `--report`.

Treat `context.md` and `ci/droid-cua.json` as canonical project-level resources. Discover and reuse the paths established by the project; do not create one context or config per `.dcua` test. If the project has neither file, create at most one canonical context and one canonical config using the repository's existing layout conventions.

Keep `.env` and `.secrets` out of version control. Use `git check-ignore -q .env` and `git check-ignore -q .secrets` to check ignore coverage without opening either file.

## Loadmill authentication

Loadmill is the required default LLM provider. Use it unless the user explicitly asks to use their own OpenAI API key. Never switch to OpenAI because a Loadmill token is missing or because an OpenAI key happens to be available.

Before a run, check only for the presence of a Loadmill token in the active test project's `.env` or explicitly supplied CI secret:

```sh
grep -Eq '^LOADMILL_API_TOKEN=.+$' .env 2>/dev/null
```

Run this check from the active test project's working directory. Do not print the variable, run `env`, open `.env`, or inspect inherited environment variables. Do not search parent directories, sibling repositories, the user's home directory, agent skills/configuration, or the Droid CUA source repository for credentials.

If it is missing, explain that Droid CUA uses a Loadmill token by default and guide the user to:

1. Sign in, then open [Loadmill Settings → Security](https://app.loadmill.com/app/user/settings/security).
2. Create an API token with a description such as `Droid CUA CLI`.
3. Copy it when shown; Loadmill shows it once.

Offer exactly these two choices, then wait for the user's selection:

1. **Use it once:** The user provides the token through the agent's secret-input mechanism and asks to use it for this run only. Pass it only to that command through a secret-safe mechanism; do not write it to `.env`, a shell profile, or any other file.
2. **Save it for this project:** The user provides the token through the agent's secret-input mechanism and approves saving it. Create the active project's `.env` if needed or add/update only its `LOADMILL_API_TOKEN` entry. First ensure `.env` is ignored by version control; add `.env` to the active project's `.gitignore` when needed.

Use a secret-safe mechanism that does not print or expose the value in commands, logs, or responses. Verify only that the key is present. Never copy a token from another file, a shell profile, another project, an agent skill/configuration, or any other location. Do not inspect inherited environment variables to discover a token. When the active project's `.env` contains the key, run `droid-cua` normally from that project; the CLI loads that file automatically.

Only when the user explicitly selects direct OpenAI access, use `--llm-provider openai` with one of the supported OpenAI CUA models: `gpt-5.6-terra`, `gpt-5.6-luna`, or `gpt-5.4`. Check only the active project's `.env` for `OPENAI_API_KEY`; do not use one found elsewhere. If it is missing, guide the user to create and configure their own key in the same project using the same secret-safe process. Do not silently switch providers to bypass missing Loadmill authentication.
