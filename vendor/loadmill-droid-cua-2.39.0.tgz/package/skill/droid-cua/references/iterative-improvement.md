# Iterative test improvement

Use this workflow after creating or changing a test, when a test is flaky or slow, or when the user asks to stabilize, heal, or optimize it. Do not wait for a failure: a green run can still contain expensive recovery loops and recurring instability.

## 1. Agree on the iterative run

Before the first run, describe the test behavior, target, user-visible side effects, and metered-resource use as required by `running-and-healing.md`. When iteration is requested, explain that the workflow includes a baseline followed by the evidence-driven edits, targeted reruns, and final representative runs needed to reach a readiness decision on the same target.

One confirmation may cover that iterative workflow. Continue without asking again merely because another rerun is needed. Confirm again before changing the app build, target, test scope, provider/model, or another user-visible side effect.

## 2. Establish a reproducible baseline

Run the narrowest test with its existing project model and config. Keep these fixed for the baseline, then change any of them only as part of a documented, evidence-supported optimization batch:

- App build and initial account/data state.
- Device, OS, device source, or browser session mode.
- Test, context, model/provider, Aim Assist, compaction, and Explain Mode settings.
- Report, debug, and cloud artifact settings.

Use `--debug` and an explicit `--report` path. Preserve the project's Explain Mode setting for the performance baseline. When reasoning is unclear, run a separate diagnostic comparison with Explain Mode enabled, then repeat final confidence runs with the intended CI setting.

On Loadmill Cloud, use `--artifacts video`, `--artifacts deviceLog,appiumLog`, or `--artifacts all` to download selected artifacts after the run reaches terminal status. `--artifacts` is Loadmill-Cloud-only. Use video when motion or timing matters and device/Appium logs when platform or automation behavior is in question. An existing cloud run can fetch artifacts retroactively with `--cloud-session-id <id> --artifacts <kinds>` and no instructions.

## 3. Build an evidence timeline

Inspect the HTML report, structured debug JSONL, safe screenshots, terminal output, and available video or platform logs. Separate cloud provisioning and artifact-download time from test execution time.

Record at least:

- Pass/fail, completed instructions, assertions, framework retries, action count, and total execution time.
- Per-instruction duration and the first divergence from expected visible behavior.
- Model rounds, screenshot-only turns, previews versus real actions, repeated coordinates, waits, compactions, and reconnects around each hotspot.
- In-step recoveries that do not increment the CLI retry counter, such as repeated typing, refocusing, reopening the app, or resubmitting.
- Whether the UI changed after each action and whether the same anomaly recurs in another run.

Rank hotspots by time, excess rounds/actions, and risk. Do not assume the slowest step is an app delay: repeated observe-decide-act cycles often dominate execution time.

## 4. Classify before editing

Use the first-divergence categories in `running-and-healing.md`, with two additional distinctions:

- **Droid/provider behavior**: aim-preview loops, compaction state loss, unsafe automation-tool behavior, model confusion despite clear instructions, or provider/network retries. Do not disguise these as app context.
- **Performance-only opportunity**: the flow is correct, but an unnecessary scenario step, redundant instruction, repeated action, or overly conservative setting adds time without coverage value.

Stop healing when evidence indicates an application regression. Preserve the failing assertion and report the product bug. Retry an unchanged test once for a plausible transient failure before editing.

## 5. Choose the smallest useful batch

For long-running tests, fix all well-supported bottlenecks that can be addressed safely before paying for another full run. Use this order to build the batch unless evidence points elsewhere:

1. **`.dcua` wording and scope**
   - Express one human-readable business goal per instruction, not one click, menu, field, dialog, or submit action per line.
   - Collapse consecutive micro-steps into the user outcome they jointly accomplish, such as `Select the desired date` or `Log out`, while keeping meaningful assertions explicit.
   - Use exact visible labels only when they disambiguate the goal or identify an outcome the test must verify.
   - Add the missing starting condition or assertion at the first ambiguous transition.
   - Remove scenario steps that do not protect the behavior under test.
   - Add lower-level actions only when the evidence shows the business-level instruction is unreliable or an intermediate state is part of the coverage.
   - Keep the existing scenario in one independently runnable `.dcua` file. Splitting a long test into ordered or state-dependent tests is not an available optimization because separate execution order and shared state are not guaranteed.
   - Never remove or weaken a meaningful assertion to obtain a pass.

2. **`context.md`**
   - Update the project's existing canonical context file; never create a test-specific context file for the optimization.
   - Add durable product navigation, terminology, stable interruptions, and narrowly observed recovery behavior.
   - Move reusable mechanics out of the test, but keep scenario-specific values and expectations in the test.
   - Remove redundant, speculative, or conflicting instructions. Do not restate Droid's base behavior or encode a workaround for a Droid/product bug as product knowledge.

3. **Test data or reproducible config**
   - Use stable, rerunnable data and prevent values from growing or colliding across runs.
   - Use the project's existing canonical config rather than creating a config for the affected test.
   - Evaluate how a setting would affect the other project tests. Use a CLI override for a temporary experiment; persist it in the canonical config only when the evidence supports making it project-wide.

4. **Execution configuration**
   - Include only settings supported by the evidence. Keep the prior run as the comparison baseline and record every override.

For every included change, record the evidence, rationale, expected effect, and preserved coverage. Bundle multiple `.dcua`, context, test-data, and configuration improvements when they address distinct observed hotspots and do not conflict. Prefer low-risk wording and context fixes; include model or execution-setting changes when evidence supports them and the saved run time outweighs the loss of perfect attribution. After editing, rerun only the affected test on the same target and compare each hotspot plus the overall result against the baseline.

## Configuration decision guide

### CUA model

- Preserve the project's model first. For a project without an established choice, use `loadmill-pulse`; it is the recommended model for daily authoring, local execution, and CI.
- Use `loadmill-smart` when stability is a real, model-related issue and comparison evidence shows that switching from Pulse improves the affected flow. Do not escalate to Smart based only on a failure, slow app transition, ambiguous test, or target problem.
- `loadmill-beacon` is opt-in and starts a fresh model conversation for every instruction. Cross-step facts come from Droid's client-owned transcript rather than a scenario-long model chain, so interpret late-run context and compaction differently and verify that cross-step references remain reliable.
- Treat a model change as a higher-risk part of the batch. Prefer addressing obvious test/context ambiguity first. Keep Smart in the final configuration only when the available evidence supports its stability benefit.
- Do not silently switch provider or model. Keep provider/model combinations valid.

### App context and prompt customizations

- Keep app context enabled for normal runs. `context.md` should describe stable product behavior, not the current scenario transcript or model strategy.
- Use `--no-context` only as a diagnostic comparison when evidence suggests stale or conflicting context; it is not a normal healing step.
- Treat base/execution prompt customizations as high-blast-radius settings because they affect every instruction. Inspect them for rules that cause repeated screenshots, waits, keyboard actions, or conflicts with Droid's base prompt.
- Prefer fixing the narrow `.dcua` instruction or `context.md` entry first. Change a shared prompt customization only when the same behavior affects multiple tests and the evidence supports the broader rule.

### Aim Assist

- `always` is the default and previews every click. It maximizes coordinate verification but adds preview rounds and latency.
- `smart` may skip preview for broad, isolated, stable targets while retaining it for small, dense, ambiguous, keyboard-adjacent, or recently changed UI. Use it when `always` adds repeated safe previews or material time.
- `off` clicks directly. Use it only for a controlled comparison or a flow whose targets are consistently large and unambiguous; watch for misclicks and neighboring controls.
- A preview followed by another screenshot instead of a real click is a diagnostic signal. Check compaction, screen changes, and prompt/context conflicts before merely changing Aim Assist.

### Context Optimization

- Context Optimization is enabled by default with a 60,000-input-token threshold. The threshold triggers compaction; it is not a guaranteed post-compaction size.
- Repeated compaction near a late-run hotspot can lose short-lived action state or add latency. Raising the threshold may reduce compaction frequency but retains more history and can increase request size, latency, and usage.
- A lower threshold reduces the working history sooner but can cause more frequent compaction and loss of relevant state in long flows.
- Disable optimization only for a short diagnostic comparison when the model/provider supports the accumulated context. Do not make disabling it the default fix for a long test.
- Prefer removing unrelated steps from the scenario or reducing unnecessary rounds before relying on a very high threshold. Do not turn one existing scenario into dependent test files as a compaction workaround.

### Explain Mode and artifacts

- Enable Explain Mode for a diagnostic comparison when the baseline does not reveal why the agent acted or stopped. It changes the execution prompt and may add tokens and latency, so do not compare its performance directly with a normal-mode baseline or silently keep it in routine CI.
- `--debug` is required for agent-observed runs because it provides structured JSONL and instruction-linked screenshots.
- Use an HTML report for every normal run. Use Loadmill Cloud video for motion/timing ambiguity and device/Appium logs for platform or automation-tool causality.

## 6. Compare and iterate

After each rerun, compare:

- Did the first divergence disappear for the expected reason?
- Did the hotspot's duration, rounds, actions, previews, retries, or recoveries improve?
- Did another step regress or did coverage change?
- Did the combined change set improve the intended hotspots without obscuring a regression?

Keep the batch when the evidence supports the overall result. If it regresses or remains ambiguous, use the timeline to isolate, revise, or revert only the suspect subset instead of automatically rerunning every change separately. Continue while the evidence supports another useful test, context, data, or configuration improvement. Stop and report the strongest remaining explanation only when a genuine blocker remains or no evidence-supported improvement is left to try.

## 7. Prove readiness

After the optimized test passes, decide whether the accumulated evidence is strong enough for the test's risk, prior flakiness, state sensitivity, and intended CI use. A clean representative pass may be sufficient when the behavior is straightforward and earlier iterations already provide consistent evidence. Run the final test unchanged again when meaningful uncertainty remains—for example after a major last edit, intermittent failures, state-dependent behavior, or a configuration change. Prefer a fresh cloud device or equivalently reset local state when repeatability across sessions matters.

Call the test ship-ready only when:

- All intended instructions and meaningful assertions pass in the final representative evidence.
- No unexplained recovery, repeated-action loop, or recurring high-risk hotspot remains.
- Timing and action counts are reasonably consistent, with transient provider retries identified separately.
- The test is rerunnable and leaves account/app state in the expected condition.
- Test, context, data, secrets references, and config are reproducible in CI.
- Reports and debug evidence exist, while secrets and generated artifacts remain uncommitted unless the project explicitly tracks them.

Report before/after metrics, the final configuration, the evidence supporting the readiness judgment, remaining product/Droid/provider risks, and exact artifact paths. State why the available run history is sufficient or why more evidence is still needed. A stable test may still reveal a separate platform or product issue; record that risk instead of encoding it into the test.

## 8. Summarize the improvement

End the work with the concise retrospective required by `running-and-healing.md`. Lead with the final result, then highlight the important problems found, the changes and their rationale, and the measured timing or stability improvement. Distill a long iteration history into the few facts the user needs to understand what became faster or more reliable and why. Separate artifact links and lower-level diagnostics from this summary.
