---
name: droid-cua
description: Operate and improve Droid CUA `.dcua` test projects. Use when the user explicitly names Droid CUA or @loadmill/droid-cua, or asks to author, configure, run, diagnose, heal, stabilize, or speed up `.dcua` tests with the Droid CUA CLI or desktop app. Do not use for general web browsing, website development, browser automation, generic mobile work, or non-Droid test tasks.
---

# Droid CUA

Use the existing `droid-cua` CLI and repository files. Do not invent commands, flags, or product capabilities.

## Workflow

1. Inspect the active test project before creating files. Find existing `.dcua` tests, `context.md`, `test-data.md`, `.secrets`, `.env`, and `ci/droid-cua.json` without reading secret values. Do not search other projects or the user's home directory for credentials.
2. Determine the requested platform and target from the task or project. Ask the user only when the choice is unclear.
3. Check authentication and environment readiness before the first run. Read [project-and-auth.md](references/project-and-auth.md) for project boundaries and token handling. Read [onboarding-and-troubleshooting.md](references/onboarding-and-troubleshooting.md) when setup, dependency, device, simulator, browser, or connection work is needed.
4. Author or update the smallest useful test. Read [authoring-tests.md](references/authoring-tests.md) before changing `.dcua`, context, test data, secrets, or config.
5. Before execution, present the proposed tests and target to the user, resolve any questions, and get their confirmation. Read [running-and-healing.md](references/running-and-healing.md) for the required pre-run check.
6. Run the confirmed, narrowest relevant test and monitor it to completion. Keep the user oriented during the run by surfacing meaningful live screenshots, not just terminal output.
7. For a new, changed, flaky, slow, or explicitly optimized test, continue with the evidence-driven author-run-improve loop in [iterative-improvement.md](references/iterative-improvement.md). A passing run is a baseline, not proof of readiness.
8. End with a short user-facing improvement summary: what was tested, the main problems found, what changed and why, measured timing or stability gains, final readiness, and any remaining risk. Include evidence paths separately without making the user reconstruct the story from reports or the full run history.

## Safety

- Never print, open, or echo secret values. Check only whether required keys are configured.
- Never search for credentials outside the active test project or source another project's `.env` file.
- Use Loadmill for every run unless the user explicitly asks to use their own OpenAI API key. A discovered OpenAI key is never permission to switch providers.
- Never use credentials from another project, a skill, an agent configuration, or the user's home directory. Configure credentials only in the active test project's `.env` (or an explicitly supplied CI secret).
- Get approval before installing dependencies, running `sudo`, accepting licenses, or changing system configuration.
- During setup, do not create or edit user tests. Rerun only the failed readiness check, then resume the original task.
- During healing, edit only `.dcua`, `context.md`, `test-data.md`, or Droid CUA config. Never modify application code under the guise of healing a test.
- Never weaken or remove an assertion merely to make a failing run pass.
- Keep one canonical context file and one canonical Droid CUA config file per test project. Reuse and update those shared files; never create test-specific context or config copies for a new or improved test.
- When improving an existing test, keep its complete flow in one independently runnable `.dcua` file. Do not split it into ordered or state-dependent tests as an optimization; Droid CUA does not currently guarantee that separate tests will run consecutively or share state.
- Before rerunning a long test, apply the smallest evidence-supported batch that addresses its known bottlenecks. The batch may include multiple `.dcua`, context, test-data, or config improvements when each has a clear rationale and preserves coverage. Record the complete change set; isolate or revert individual changes only if the combined result regresses or remains ambiguous.
- When the user asks to create, improve, heal, stabilize, or optimize a test, continue the evidence-driven edit/rerun loop through a final representative run until the test is ready or a genuine blocker remains. Do not stop because an arbitrary number of reruns has been reached.
- Stop immediately when evidence indicates a likely application regression; do not rewrite the test to match broken behavior.
- Gracefully allow cloud runs to finish cleanup. Avoid terminating a metered device session unless necessary.

## Operating principles

- Prefer an existing project convention over creating a parallel structure.
- Prefer headless runs for agent work because they are observable and return deterministic exit codes.
- Write tests as concise, human-readable user journeys. Prefer one business-level instruction per user goal over one instruction per tap, menu, dialog, or other UI gesture; add lower-level guidance only when run evidence shows it is necessary.
- Use explicit, user-observable outcomes in tests rather than implementation details or coordinates.
- Diagnose the first divergence between the instruction and observed behavior before changing anything.
- Compare runs on the same target and app build, and clearly identify every test, context, data, model, or config change included in the optimization batch.
- Treat internal recovery loops, repeated screenshots, previews, compactions, and retries as stability signals even when the run passes.
