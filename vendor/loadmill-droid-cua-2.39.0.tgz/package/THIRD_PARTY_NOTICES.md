# Third-Party Notices

Desktop control uses `@zavora-ai/computer-use-mcp` version 7.1.0.

Copyright (c) Zavora AI contributors. Licensed under the MIT License. The dependency's complete license text is distributed with its npm package.
