# droid-cua

<p align="center">
  <a href="https://www.npmjs.com/package/@loadmill/droid-cua"><img src="https://img.shields.io/npm/v/@loadmill/droid-cua?color=green" alt="npm version"></a>
</p>

<p align="center">
  <a href="#what-is-droid-cua">What is droid-cua?</a> •
  <a href="#quick-start">Quick Start</a> •
  <a href="#platforms">Platforms</a> •
  <a href="#features">Features</a> •
  <a href="#how-it-works">How It Works</a> •
  <a href="#cli-and-automation">CLI & Automation</a> •
  <a href="#license">License</a>
</p>

---

**AI-powered mobile testing desktop app for Android and iOS**

Create, run, and manage mobile tests with natural language. The desktop app guides setup, connects to your target device or simulator, and turns AI exploration into reusable test scripts.

https://github.com/user-attachments/assets/b9e15a1d-8072-4a2f-a4c5-db180ae38620

---

<h2 id="what-is-droid-cua">💡 What is droid-cua?</h2>

`droid-cua` is a desktop app for AI-powered mobile testing.

It helps teams create, edit, and run tests for **Android devices and emulators** and **iOS simulators on macOS** using natural language instead of traditional test code.

Under the hood, `droid-cua` uses an AI agent to explore your app, execute actions, and save reusable test scripts that can also be run later in headless workflows.

---

<h2 id="quick-start">🚀 Quick Start</h2>

**1. Download the desktop app**

- Mac: [Download](https://github.com/loadmill/droid-cua-release/releases/latest/download/Loadmill-Droid-CUA.dmg)
- Mac (Intel): [Download](https://github.com/loadmill/droid-cua-release/releases/latest/download/Loadmill-Droid-CUA-intel.dmg)
- Windows: [Download](https://github.com/loadmill/droid-cua-release/releases/latest/download/Loadmill-Droid-CUA-Setup.exe)

**2. Launch the app**

Open the desktop app and choose the platform you want to test.

**3. Choose your AI provider**

In Settings, choose the CUA model you want to run. Loadmill Smart is the
recommended option, Pulse is fast and efficient, and Beacon is experimental.
The Loadmill models use your Loadmill sign-in and usage tracking. The OpenAI
models use your own OpenAI API key.

**4. Connect a target device**

- Android: connect a device or select an emulator
- iOS: choose a simulator on macOS

**5. Create or run a test**

Use the desktop app to create a new test, edit an existing one, or run a saved script with live execution logs.

You can also keep project run history in a results folder and review past runs from desktop app reports.

---

<h2 id="platforms">📱 Platforms</h2>

- **Android** - Physical devices and emulators
- **iOS** - Simulators on macOS

Desktop app support:
- macOS: Android and iOS simulator workflows
- Windows: Android workflows only

## Requirements

**All platforms:**
- Loadmill sign-in for the Loadmill models, or an OpenAI API key for the OpenAI models
- Node.js 20 or newer for CLI use

**Android:**
- Android Debug Bridge (ADB)
- Android Emulator CLI for launchable emulators

**iOS (macOS only):**
- Xcode with iOS Simulator
- Appium
- XCUITest driver

---

<h2 id="features">✨ Features</h2>

- **Desktop-first workflow** - Create, run, and manage tests from one app
- **Setup guidance** - Configure API access and platform prerequisites in the app
- **Device and simulator connection** - Connect Android targets and iOS simulators
- **Natural-language test creation** - Describe flows in plain English
- **Test management** - Create, edit, save, and rerun reusable scripts, including tests organized in nested project folders
- **Live execution logs** - Watch actions and progress as tests run
- **Reports and history** - Review past runs from a project results folder inside the desktop app
- **JUnit XML output** - Write standard test reports for CI systems and external tooling
- **Run video export** - Generate and download a polished MP4 replay from a desktop run's screenshots and instruction timeline
- **Headless support** - Reuse scripts in CLI and automation workflows

---

<h2 id="how-it-works">🔧 How It Works</h2>

1. The desktop app connects to an Android device or emulator through ADB, or to an iOS simulator through Appium + XCUITest
2. Captures full-screen device screenshots
3. Scales down the screenshots for OpenAI model compatibility
4. Sends screenshots and user instructions to OpenAI's computer-use model
5. Receives structured actions such as click, scroll, type, keypress, wait, and drag
6. Rescales model outputs back to real device coordinates
7. Executes the actions on the device or simulator
8. Validates assertions and handles failures
9. Repeats until task completion

---

<h2 id="cli-and-automation">💻 CLI & Automation</h2>

The desktop app is the primary way to use `droid-cua`.

For CI, scripting, or advanced workflows, `droid-cua` also includes a CLI for running saved instructions headlessly.

Desktop projects can also keep run reports in a results folder, including JUnit XML output that the app can read back as project history.

When a desktop project contains nested folders, the app discovers `.dcua` files recursively and displays their directory structure in the project tree. You can create tests in nested folders, open those folders in Finder, drag tests between project roots and nested folders, run an individual test, run a nested folder and all its descendants, or run the entire project. Nested tests use the configured project folder's `context.md`, `test-data.md`, `.secrets`, results folder, and desktop execution settings.

The recommended workflow is:
- design and debug tests in the desktop app,
- commit the `.dcua` file plus a headless CLI config file,
- run the same test headlessly in CI with `--config` for prompt parity.

Install:
```sh
npm install -g @loadmill/droid-cua
```

Install the bundled Agent Skill for your coding agent:

In the desktop app, choose **Help → Install Droid CUA Skill**, then select your
coding agent from the submenu. The app installs the skill globally for your user account.

Alternatively, install it from the CLI:

```sh
# Global installation (default)
droid-cua skill install cursor
droid-cua skill install claude-code
droid-cua skill install codex

# Or install in the current project
droid-cua skill install codex --local
```

Use `droid-cua skill status <agent>` to inspect an installation and
`droid-cua skill uninstall <agent>` to remove it. Installed skill
files are never overwritten or removed after local modification unless `--force`
is supplied. After upgrading the npm package, update an installed skill explicitly:

```sh
droid-cua skill install <agent> --force
```

Examples:
```sh
# Interactive CLI
droid-cua

# Headless Android run
droid-cua run tests/login.dcua --avd adb:emulator-5554

# Headless Android folder run
droid-cua run tests --avd adb:emulator-5554

# Select tests from different folders
droid-cua run tests/auth/login.dcua tests/checkout/purchase.dcua admin/refund.dcua \
  --avd adb:emulator-5554

# Headless iOS simulator run
droid-cua run tests/login.dcua --platform ios --avd "iPhone 16"

# List running desktop applications and their window IDs (macOS or Windows)
droid-cua --target desktop --list-desktop-apps

# Control one already-running desktop application window
droid-cua --target desktop --desktop-app com.apple.TextEdit --desktop-window 123 --instructions tests/editor.dcua

# Explicitly use cursor-free accessibility input instead of the default physical input
droid-cua --target desktop --desktop-app com.apple.TextEdit --desktop-input accessibility --instructions tests/editor.dcua

# Headless run with prompt-parity config
droid-cua --avd adb:emulator-5554 --instructions tests/login.dcua --config ci/droid-cua.json

# Headless LambdaTest real-device run
LAMBDATEST_USERNAME=... LAMBDATEST_ACCESS_KEY=... droid-cua \
  --device-source lambdatest \
  --platform android \
  --device-name "Galaxy S24" \
  --os-version "14" \
  --app ./app/build/outputs/apk/debug/app-debug.apk \
  --instructions tests/login.dcua \
  --config ci/droid-cua.json

# List AWS Device Farm remote-access devices
AWS_DEVICE_FARM_ACCESS_KEY_ID=... \
AWS_DEVICE_FARM_SECRET_ACCESS_KEY=... \
AWS_DEVICE_FARM_PROJECT_ARN=... \
droid-cua --device-source aws-device-farm --list-devices

# Headless AWS Device Farm real-device run
AWS_DEVICE_FARM_ACCESS_KEY_ID=... \
AWS_DEVICE_FARM_SECRET_ACCESS_KEY=... \
AWS_DEVICE_FARM_PROJECT_ARN=... \
droid-cua \
  --device-source aws-device-farm \
  --platform android \
  --device-name "Google Pixel 10 Pro" \
  --os-version "16" \
  --app ./app/build/outputs/apk/debug/app-debug.apk \
  --instructions tests/login.dcua
```

`droid-cua run` accepts one or more `.dcua` files or directories. Inputs are
expanded in the order provided, files inside each directory retain their natural
name ordering, and overlapping paths are run only once. A single config, target,
context, test-data file, and secrets source applies to the entire invocation.
The `run` command must be the first argument. Keep all selected paths contiguous
and place options after the complete path list. Arbitrary option/path
interleaving is not supported.
The existing `--instructions <file-or-directory>` form remains supported for
backward compatibility.

Example headless config:
```json
{
  "cuaModel": "gpt-5.4",
  "promptCustomizations": {
    "basePromptInstructions": "",
    "designModeInstructions": "",
    "executionModeInstructions": ""
  },
  "appContextEnabled": true,
  "appContextPath": "../tests/context.md",
  "contextOptimizationEnabled": true,
  "contextOptimizationThreshold": 60000
}
```

Typical CI-style usage:
```sh
droid-cua \
  --avd adb:emulator-5554 \
  --instructions tests/login.dcua \
  --config ci/droid-cua.json \
  --debug
```

Supported CLI options include:
- `--avd`
- `--platform`
- `--device-source`
- `--device-name`
- `--os-version`
- `--app`
- `--list-devices`
- `--browser`
- `--target` (`mobile`, `web`, or `desktop`)
- `--desktop-app` (desktop application ID or exact name)
- `--desktop-window` (required when the application has multiple visible windows)
- `--desktop-input` (`physical` by default; use `accessibility` for cursor-free input)
- `--list-desktop-apps`
- `--instructions`
- `--config`
- `--cua-model`
- `--context`
- `--no-context`
- `--context-optimization-threshold`
- `--no-context-optimization`
- `--explain`
- `--base-prompt`
- `--execution-prompt`
- `--base-prompt-file`
- `--execution-prompt-file`
- `--secrets`
- `--record`
- `--report`
- `--no-cloud-report`
- `--debug`

`--cua-model` accepts `loadmill-smart`, `loadmill-pulse`, `loadmill-beacon`,
`gpt-5.6-terra`, `gpt-5.6-luna`, and `gpt-5.4`. OpenAI models use direct OpenAI
mode and require `OPENAI_API_KEY`.

Desktop control supports macOS and Windows. In the desktop app, enable **Experimental desktop control** at the bottom of Settings to show Desktop in the platform picker. Desktop runs use visual input by default: they capture the selected window and send physical pointer and keyboard input at the model's coordinates. Use `--desktop-input accessibility` for cursor-free CLI input instead. macOS requires Screen & System Audio Recording and Accessibility permissions for Droid or the terminal running the CLI. Windows targets must run at the same integrity level as Droid; a non-elevated Droid process cannot inject input into an elevated application.

Config and precedence rules:
- Use `--config <file>` to supply prompt-affecting settings for headless runs.
- CLI flags override config file values.
- `--context` overrides the config app-context path.
- `--no-context` disables app context entirely.
- Context Optimization is enabled by default with a `60000` input-token threshold.
- `--context-optimization-threshold <tokens>` sets the threshold and enables Context Optimization.
- `--no-context-optimization` disables Context Optimization.
- Explain Mode is enabled by default and asks the agent for concise explanations of non-obvious decisions, skipped actions, and completion evidence; explanations appear in terminal output and reports.
- Set `"explainMode": false` in the JSON config to disable it. The `--explain` flag remains available to explicitly enable it for a run.
- `--base-prompt` and `--execution-prompt` let you pass prompt customizations inline on the command line.
- `--base-prompt-file` and `--execution-prompt-file` override the corresponding prompt customizations from config.
- If both inline and file-based prompt overrides are provided, the inline prompt flags win.

Secret typing:
- Put runtime typing secrets in a project `.secrets` file using dotenv-style `KEY=value` lines.
- Desktop execution and design mode load `.secrets` from the selected project folder. Headless CLI loads `.secrets` from the current working directory.
- Headless CLI also accepts `--secrets KEY=value,OTHER=value`; these values override `.secrets` for that run.
- The agent sees only secret keys and may call `type_sensitive_text({ key })`. Logs and reports may include keys, but not resolved values.
- Screenshot masking is out of scope. Secret values also necessarily pass through ADB, Appium, or browser automation while being typed.

HTML report (`--report`):
- Writes a self-contained HTML report of the run — the same Run Details view the desktop app shows, with screenshots inlined — that you can share and open in any browser.
- With no value it saves `<test>--<date>--<time>.html` (e.g. `login--2026-06-03--16-09-20.html`) in the current directory; pass `--report <file>` to pick a filename or `--report <dir>` to pick a folder.
- A multi-path selection writes the individual test reports plus one aggregate `Selected tests` report with a child result and timeline for every selected test. When `--report <file.html>` is used, that exact path is used for the aggregate report.
- In the desktop app the same report is available from a run's **Share → Download HTML report** button.
- Runs with captured screenshots also expose **Share → Generate video**. The desktop app renders portrait mobile runs as square replays and landscape mobile, web, and desktop runs as 16:9 replays. Landscape Android and iOS screenshots keep a device frame sized to the captured screen instead of browser chrome. Rendering happens locally, then the app prompts for a save location using `<test>--<date>--<time>--test-replay.mp4` as the suggested filename. While rendering, a compact **Background tasks** card shows progress for **Generating test replay**; it can be minimized to a task-count card or canceled without opening the save dialog.
- Authenticated headless runs upload their HTML report and screenshots to Loadmill by default. The Loadmill run record also includes the resolved Droid version, model, provider, Agent Pace, Aim Assist, Context Optimization, and target environment. Use `--no-cloud-report` to disable artifact upload; the Droid run record is still reported.

```sh
droid-cua run tests/login.dcua --avd adb:emulator-5554 --report ./reports
```

LambdaTest CLI runs:
- Use `--device-source lambdatest` with `--platform`, `--device-name`, `--os-version`, `--app`, and `--instructions`.
- Set `LAMBDATEST_USERNAME` and `LAMBDATEST_ACCESS_KEY` in the environment.
- Android LambdaTest runs require an `.apk`; iOS LambdaTest runs require an `.ipa`.
- The CLI uploads the app to LambdaTest for each run and closes the cloud session when the run finishes or fails.
- Each CLI LambdaTest run gets a unique LambdaTest build name so repeated local runs are easy to distinguish in the LambdaTest UI.

AWS Device Farm CLI runs:
- Use `--device-source aws-device-farm` with `--platform`, `--device-name`, `--os-version`, `--app`, and `--instructions`.
- Set `AWS_DEVICE_FARM_ACCESS_KEY_ID`, `AWS_DEVICE_FARM_SECRET_ACCESS_KEY`, and `AWS_DEVICE_FARM_PROJECT_ARN` in the environment (an IAM user with Device Farm access and the ARN of a Device Farm project in `us-west-2`).
- `--device-source aws-device-farm --list-devices` prints the remote-access device catalog (name, platform, OS) so you can pick valid `--device-name`/`--os-version` values, then exits.
- Android runs require an `.apk`; iOS runs require an `.ipa`. `.app` bundles are not supported.
- Re-running with the same app binary skips the upload: uploads are cached by checksum and reused for up to 30 days (Device Farm's upload retention).
- Device provisioning takes ~1 minute; the CLI shows live progress while it waits.
- The session is stopped when the run finishes, fails, or is interrupted with Ctrl-C — billing stops as soon as the stop is requested, so the CLI does not wait for the session to fully wind down.

AWS Device Farm in the desktop app:
- Open **Integrations → AWS Device Farm** and enter an AWS Access Key ID + Secret Access Key. The keys are validated on connect, a `droid-cua` Device Farm project is created automatically (the IAM user needs the minimal Device Farm policy, including `ListProjects`/`CreateProject`), and the remote-access device catalog loads. Credentials are stored in plaintext `desktop-config.json`, the same as BrowserStack/LambdaTest.
- On the Devices page, pick AWS Device Farm as the source, choose a device + an uploaded `.apk`/`.ipa`, and start a Design/Run session. Provisioning takes ~1 minute and live progress flows into the device log.
- **Pause caveat:** a Device Farm session paused for more than 5 minutes may be ended by AWS and need reconnecting.

Minimal GitHub Actions shape:
```yaml
jobs:
  droid-cua:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-node@v4
        with:
          node-version: 20
      - run: npm install -g @loadmill/droid-cua
      - run: |
          droid-cua \
            --device-source lambdatest \
            --platform android \
            --device-name "Galaxy S24" \
            --os-version "14" \
            --app ./app/build/outputs/apk/debug/app-debug.apk \
            --instructions tests/login.dcua \
            --config ci/droid-cua.json \
            --debug
        env:
          OPENAI_API_KEY: ${{ secrets.OPENAI_API_KEY }}
          LAMBDATEST_USERNAME: ${{ secrets.LAMBDATEST_USERNAME }}
          LAMBDATEST_ACCESS_KEY: ${{ secrets.LAMBDATEST_ACCESS_KEY }}
```

The same shape works for AWS Device Farm — swap the run step and env:
```yaml
      - run: |
          droid-cua \
            --device-source aws-device-farm \
            --platform android \
            --device-name "Google Pixel 10 Pro" \
            --os-version "16" \
            --app ./app/build/outputs/apk/debug/app-debug.apk \
            --instructions tests/login.dcua \
            --config ci/droid-cua.json \
            --debug
        env:
          OPENAI_API_KEY: ${{ secrets.OPENAI_API_KEY }}
          AWS_DEVICE_FARM_ACCESS_KEY_ID: ${{ secrets.AWS_DEVICE_FARM_ACCESS_KEY_ID }}
          AWS_DEVICE_FARM_SECRET_ACCESS_KEY: ${{ secrets.AWS_DEVICE_FARM_SECRET_ACCESS_KEY }}
          AWS_DEVICE_FARM_PROJECT_ARN: ${{ secrets.AWS_DEVICE_FARM_PROJECT_ARN }}
```

Example without a config file:
```sh
droid-cua \
  --avd adb:emulator-5554 \
  --instructions tests/login.dcua \
  --context tests/context.md \
  --base-prompt "stop and look at the screen after every action you take."
```

Headless debug artifacts:
- `--debug` writes desktop-style structured JSONL artifacts under `logs/`.
- Each run creates `logs/execution-<runId>-<timestamp>.jsonl`.
- Each run also creates a sibling screenshot folder next to that JSONL file.
- Shared device events are written to `logs/device-events.jsonl`.
- `--debug` no longer creates the legacy `logs/debug-*.log` file for headless runs.
- If `--debug` and `--record` are both used, screenshots are written to both the debug artifacts folder and the legacy `droid-cua-recording-<timestamp>` folder.

Current headless behavior is documented in [docs/headless-cli-spec.md](docs/headless-cli-spec.md).

---

<h2 id="license">📄 License</h2>

© 2026 Loadmill. All rights reserved.
